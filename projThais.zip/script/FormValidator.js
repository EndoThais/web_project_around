export default class FormValidator {
  constructor(config, formElement) {
    this._config = config;
    this._formElement = formElement;
    this._inputs = Array.from(
      this._formElement.querySelectorAll(this._config.input)
    );
    this._buttonSubmit = this._formElement.querySelector(
      this._config.submitButton
    );
  }

  enableValidation() {
    this._inputs.forEach(function (inputElement) {
      inputElement.addEventListener("input", function () {
        checkInputValidity(inputElement, this._formElement);
        console.log("entrou");
      });
    });
  }

  //conectando os métodos de validação
  _showInputError(inputElement, errorMessage) {
    const errorElement = this._formElement.querySelector(
      `.${inputElement.id}-input-error`
    );
    // inputElement.classList.add(this._config.input_type_error);
    errorElement.textContent = errorMessage;
    errorElement.classList.add(this._config.input_error_active);
  }

  _hideInputError(inputElement) {
    const errorElement = this._formElement.querySelector(
      `.${inputElement.id}-input-error`
    );
    // inputElement.classList.remove(this._config.input_type_error);
    errorElement.classList.remove(this._config.input_error_active);
    errorElement.textContent = "";
  }

  _checkInputValidity(inputElement, formElement) {
    if (!inputElement.validity.valid) {
      this._showInputError(
        formElement,
        inputElement,
        inputElement.validationMessage
      );
    } else {
      this._hideInputError(formElement, inputElement);
    }
  }
}
